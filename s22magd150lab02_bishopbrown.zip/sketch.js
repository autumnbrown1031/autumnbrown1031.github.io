function setup() {
  createCanvas(600, 300);
}

function draw() {
  background(15);
  
  push();
  noFill(0);
  noStroke();
  fill('#FAB91D');
  ellipse(500, 75, -85, -85);
  pop();
  
  push();
  noFill();
  stroke(255);
  strokeWeight(2);
  bezier(540, 90, 730, 155, 250, 15, 458, 65);
  pop();
  
  push();
  colorMode(HSB);
  fill(42, 43, 98);
  noStroke();
  ellipse(500, 60, -10, -10);
  colorMode(HSB);
  fill(42, 43, 98);
  noStroke();
  ellipse(510, 100, -15, -15);
  colorMode(HSB);
  fill(42, 89, 86);
  noStroke();
  ellipse(520, 70, -20, -20);
  
  pop();
  
  push();
  stroke(255);
  strokeWeight(3);
  point(375, 75);
  point(330, 55);
  point(280, 50);
  point(215, 75);
  point(150, 95);
  point(130, 60);
  point(195, 40);
  pop();
  
  push();
  noFill(0);
  quad(130, 60, 195, 40, 215, 75, 150, 95);
  pop();
  
  line(215, 75, 280, 50);
  line(280, 50, 330, 55);
  line(330, 55, 375, 75);
  stroke(255);
  
  push();
  strokeWeight(0);
  fill(20);
  ellipse(550, 150, -55, -55);
  pop();
  
  push();
  strokeWeight(0);
  fill(200);
  arc(550, 150, -55, -55, -300, PI + HALF_PI, CHORD);
  pop();  
  
  push();
  fill(230);
  stroke(230);
  ellipse(540, 135, -10, -10);
  fill(245);
  stroke(245);
  ellipse(535, 145, -5, -5);
  fill(185);
  stroke(185);
  ellipse(540, 160, -8, -8);
  pop();
  
  push();
  stroke(255);
  strokeWeight(3);
  point(100, 200);
  point(90, 215);
  point(125, 195);
  point(150, 225);
  point(151, 217);
  point(152, 210);
  pop();
  
  line(100, 200, 90, 215);
  line(100, 200, 125, 195);
  line(125, 195, 152, 210);
  line(152, 210, 151, 217);
  line(151, 217, 150, 225);
  line(90, 215, 150, 225);
  stroke(255);
  
  push();
  stroke(255);
  strokeWeight(3);
  point(160, 260);
  point(190, 230);
  pop();
  
  push();
  noFill(0);
  quad(150, 225, 160, 260, 190, 230, 152, 210);
  pop();
  
  push();
  stroke(255);
  strokeWeight(3);
  point(185, 160);
  point(160, 150);
  point(145, 160);
  point(200, 175);
  point(200, 185);
  point(75, 205);
  point(60, 190);
  point(45, 160);
  point(70, 175);
  point(75, 150);
  pop();
  
  line(125, 195, 185, 160);
  line(160, 150, 145, 160);
  line(160, 150, 185, 160);
  line(185, 160, 200, 175);
  line(200, 175, 200, 185);
  line(90, 215, 75, 205);
  line(75, 205, 60, 190);
  line(60, 190, 45, 160);
  line(60, 190, 70, 175);
  line(70, 175, 75, 150);
  stroke(255);
  
  push();
  noFill();
  noStroke();
  colorMode(RGB);
  fill(38, 69, 240);
  ellipse(70, 70, -30, -30);
  pop();
  
  push();
  noFill();
  noStroke();
  colorMode(HSB);
  fill(331, 66, 98);
  ellipse(300, 150, -40, -40);
  pop();
  
  push();
  noFill();
  noStroke();
  colorMode(RGB);
  fill(250, 32, 16);
  ellipse(350, 200, -25, -25);
  pop();
  
  push();
  stroke(255);
  strokeWeight(3);
  point(50, 60);
  point(70, 40);
  point(300, 75);
  point(575, 250);
  point(285, 275);
  point(250, 200);
  point(390, 225);
  point(30, 230);
  pop();
  
  push();
  stroke(255);
  strokeWeight(5);
  point(20, 225);
  point(400, 15);
  point(550, 25);
  point(260, 50);
  point(560, 60);
  point(450, 150);
  point(375, 250);
  pop();
  
}