function setup() {
  createCanvas(500, 300);
}


function draw() {
  background(245);
  line(0, 150, 500, 150);
  stroke(0);
  
  fill(175);
  ellipse(255, 30, -10, -10);
  stroke(0);
  line(255, 10, 255, 25);
  fill(75);
  stroke(0);
  rect(275, 150, -40, -115);
  
  fill(50);
  stroke(0);
  rect(235, 150, -15, -50);

  fill(35);
  stroke(0);
  rect(220, 150, -30, -90);
  
  
  fill(35);
  stroke(0);
  rect(180, 150, -40, -120);
  
  fill(200);
  stroke(0);
  rect(200, 150, -50, -70);
  
  fill(50);
  stroke(0);
  rect(140, 150, -10, -55);
  
  fill(25);
  noStroke(0);
  rect(130, 150, -15, -100);
  
  fill(25);
  noStroke(0);
  rect(115, 150, -25, -145);
  
  fill(25);
  noStroke(0);
  rect(90, 150, -15, -100);
  
  fill(175);
  stroke(0);
  rect(80, 150, -30, -90);
  
  push();
  rectMode(CENTER);
  fill(100);
  noStroke(0);
  rect(65, 105, 13, 80);
  pop();
  
  fill(150);
  stroke(0);
  rect(50, 150, -20, -110);
  
  fill(90);
  ellipse(15, 100, -10, -10);
  stroke(0);
  line(15, 85, 15, 95);
  fill(125);
  stroke(0);
  rect(30, 150, -30, -45);
  
  fill(50);
  stroke(0);
  rect(300, 150, -15, -70);

  fill(190);
  stroke(0);
  rect(290, 150, -25, -40);
  
  fill(30);
  stroke(0);
  rect(340, 150, -25, -135);
  
  fill(150);
  stroke(0);
  rect(330, 150, -30, -50);
  
  fill(80);
  stroke(0);
  rect(370, 150, -30, -120);
  
  push();
  rectMode(CENTER);
  fill(245);
  rect(355, 90, 15, 100);
  pop();
  
  fill(200);
  stroke(0);
  rect(380, 150, -10, -40);
  
  fill(200);
  stroke(0);
  rect(400, 150, -20, -50);
  
  fill(200);
  stroke(0);
  rect(410, 150, -10, -40);
  
  fill(30);
  stroke(0);
  rect(440, 150, -30, -80);
  
  fill(15);
  noStroke(0);
  rect(460, 150, -20, -100);
  
  fill(75);
  stroke(0);
  rect(480, 150, -25, -70);
  
  fill(230);
  noStroke(0);
  rect(470, 149, -50, -30);
  
  fill(225);
  stroke(0);
  rect(500, 150, -20, -35);
  
  push();
  strokeWeight(3);
  point(163, 90);
  point(188, 90);
  point(163, 100);
  point(188, 100);
  point(163, 110);
  point(188, 110);
  point(163, 120);
  point(188, 120);
  point(163, 130);
  point(188, 130);
  point(163, 140);
  point(188, 140);
  point(176, 90);
  point(176, 100);
  point(176, 110);
  point(176, 120);
  point(176, 130);
  point(176, 140);
  pop();
  
  
}