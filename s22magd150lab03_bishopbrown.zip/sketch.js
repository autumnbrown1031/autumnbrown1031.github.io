let x;


function setup() {
  createCanvas(500, 500);
  x=0;
  
  
}


function draw() {
  background(100);
  

  
  print("LOOK AT THE SKY");
  print(2 + 4 * 2);
  print(5 == 7 - 3);
  
  ellipseMode(CENTER);
  strokeWeight(3);
  fill(109, 51, 240);  
  ellipse(mouseX, mouseY, pmouseX, pmouseY);
  print(pmouseX + ' -> ' + mouseX);
  
  push();
  fill(255, 122, 0);
  frameRate(30);
  ellipse(x, 100, 100, 100);
  x++;  
  pop();
  
  fill(37, 240, 2);
  let x1 = map(mouseX, 100, width, 30, 85);
  ellipse(x1, 15, 15, 15);
  let x2 = map(mouseX, 100, width, 50, 125, true);
  ellipse(x2, 75, 75, 75);
  let maxX = 250;
  let maxY = 290;
  
  push();
  strokeWeight(1);
  stroke(0, 245, 243);
  line(0, 250, 500, 250, width, height);
  print("cyan line distance: " + dist(0, 0, width, height));
  pop();
  
 let mood = 'happy';
  console.log(typeof mood);
 
  print(float('250.15'));
  
  
}