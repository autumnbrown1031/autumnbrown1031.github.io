function setup() {
  createCanvas(500, 500);
  background(255);
  noStroke(0);
  fill('#EBBD83');
  ellipse(250, 250, 300, 300);
 
 
}



let x = '#FF342A';
let value = '#EBBD83';
function draw() {
  push();
  fill(value);
  translate(width/2, height/2);
  rotate(frameCount * 0.025);
  ellipse(0, 50, 150, 150);  
  pop();
 
  push();
  stroke(0);
  fill(x);
  ellipse(150, 250, 25, 25);
  pop();
 
 

 
 
}
function mousePressed() {
 if (value === '#F54726') {
    value = '#661B0F';
  } else {
    value = '#F54726';
  }
 

   
   
}